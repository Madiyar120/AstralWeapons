package me.astralsmp.weapons;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ShadowBladeCommand implements CommandExecutor {
    private final ShadowBlade shadowBlade;

    public ShadowBladeCommand(ShadowBlade shadowBlade) {
        this.shadowBlade = shadowBlade;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!player.isOp()) {
            player.sendMessage(ChatColor.RED + "Только оператор может использовать эту команду.");
            return true;
        }
        player.getInventory().addItem(shadowBlade.createShadowBlade());
        player.sendMessage(ChatColor.DARK_PURPLE + "✦ Shadow Blade получен!");
        return true;
    }
}
