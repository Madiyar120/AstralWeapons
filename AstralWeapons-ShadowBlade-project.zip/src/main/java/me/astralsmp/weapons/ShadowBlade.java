package me.astralsmp.weapons;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ShadowBlade implements Listener {
    private final AstralWeapons plugin;
    private final NamespacedKey key;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private static final long COOLDOWN = 40_000L;

    public ShadowBlade(AstralWeapons plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "shadow_blade");
    }

    public ItemStack createShadowBlade() {
        ItemStack sword = new ItemStack(Material.NETHERITE_SWORD);
        ItemMeta meta = sword.getItemMeta();
        meta.setDisplayName(ChatColor.DARK_PURPLE + "Shadow Blade");
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        sword.setItemMeta(meta);
        return sword;
    }

    @EventHandler
    public void onRightClick(PlayerInteractEvent event) {
        if (!event.getAction().isRightClick()) return;

        ItemStack item = event.getItem();
        if (item == null || item.getType() != Material.NETHERITE_SWORD) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null || !meta.getPersistentDataContainer().has(key, PersistentDataType.BYTE)) return;

        Player player = event.getPlayer();
        long now = System.currentTimeMillis();
        Long end = cooldowns.get(player.getUniqueId());

        if (end != null && end > now) {
            int seconds = (int)Math.ceil((end - now) / 1000.0);
            player.sendMessage(ChatColor.GRAY + "Shadow Blade: КД " + ChatColor.LIGHT_PURPLE + seconds + " сек.");
            return;
        }

        cooldowns.put(player.getUniqueId(), now + COOLDOWN);

        player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 20 * 20, 1));
        player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 20, 1));

        // Java: native item cooldown indicator.
        player.setCooldown(Material.NETHERITE_SWORD, 20 * 40);

        player.sendMessage(ChatColor.DARK_PURPLE + "✦ Shadow Blade активирован!");

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) {
                player.sendMessage(ChatColor.LIGHT_PURPLE + "✦ Shadow Blade готов!");
            }
        }, 20L * 40);
    }
}
