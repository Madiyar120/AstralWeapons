package me.astralsmp.weapons;

import org.bukkit.plugin.java.JavaPlugin;

public class AstralWeapons extends JavaPlugin {
    @Override
    public void onEnable() {
        ShadowBlade shadowBlade = new ShadowBlade(this);
        getServer().getPluginManager().registerEvents(shadowBlade, this);
        getCommand("shadowblade").setExecutor(new ShadowBladeCommand(shadowBlade));
        getLogger().info("AstralWeapons enabled!");
    }
}
